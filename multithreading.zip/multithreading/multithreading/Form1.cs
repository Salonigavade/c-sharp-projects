﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multithreading
{
    public partial class Form1 : Form
    {
        int x = 50, y = 50, x1 = 50, y1 = 100;
        int flag = 0, flag1 = 0, f = 0;
        int dx = 30, dy= 20;
        Graphics graphic;
        Thread thread1, thread2;
        int ball_x, ball_y;


        public Form1()
        {
            InitializeComponent();
            this.Paint += new PaintEventHandler(paintBall);
            this.DoubleBuffered = true;
        }

        private void paintBall(object sender, PaintEventArgs e)
        {
            graphic = e.Graphics;
            SolidBrush solidBrush = new SolidBrush(Color.Yellow);
            graphic.FillEllipse(solidBrush, x, y, 20, 20);
            SolidBrush solidBrush2 = new SolidBrush(Color.Blue);
            graphic.FillEllipse(solidBrush2, x1, y1, 20, 20);

            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            flag = 1;
            flag1 = 1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            thread1 = new Thread(p =>
              {
                  while (flag != 1)
                  {
                      ball_x = x + dx;
                      if (ball_x < -5 || ball_x > this.ClientSize.Width)
                      {
                          dx = -dx;
                      }
                      if (ball_x == this.ClientSize.Width)
                      {
                          f = 1;
                      }
                      while (ball_y < this.ClientSize.Width && f == 1)
                      {
                          Thread.Sleep(10);

                      }
                      f = 0;
                      x += dx;
                      Invalidate();
                      Thread.Sleep(100);

                  }
                  flag = 0;
              })
            { IsBackground = true };
            thread1.Start();

            thread2 = new Thread(p =>
              {
                  while (flag1 != 1)
                  {
                      ball_y = x1 + dy;
                      if (ball_y < -5 || ball_y > this.Width)
                      {
                          dy = -dy;
                      }
                      x1 += dy;
                      Invalidate();
                      Thread.Sleep(100);
                  }
                  flag1 = 0;
              })
            { IsBackground=true};
            thread2.Start();
        }

       
    }
}
