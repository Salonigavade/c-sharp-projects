﻿using System;

namespace inheritance
{
    class facto
    {
        public void factorial()
        {
            int num, fact = 1;
            Console.WriteLine("enter num to find factorial");
            num = Convert.ToInt32(Console.ReadLine());
            for(int i = 1; i <= num; i++)
            {
                fact = fact * i;
            }
            Console.WriteLine("factorial of:" + fact);
        }
    }
    class prime : facto
    {
       public  void calculate()
        {
            int num, flag = 0;
            Console.WriteLine("enter num to find prime or not:");
            num = Convert.ToInt32(Console.ReadLine());
            for (int i = 2; i <= (num/2); i++)
            {
                if (num % i == 0)
                {
                    flag = 1;
                    break;
                }
              
            }
            if (flag == 0)
            {
                Console.WriteLine("Prime number:" + num);
            }
            else
            {
                Console.WriteLine("Not Prime number:" + num);
            }
        }
    }
    class b : prime
    {
        public void armstrong()
        {
            int r, num, sum = 0;
            Console.WriteLine("Enter number to check armstrong num:");
            num = Convert.ToInt32(Console.ReadLine());
            int num1 = num;
            while (num1 >= 1) { 
            r = num1 % 10;
            sum = sum + (r * r * r);
            num1 = num1 / 10;
            }
            if (sum == num) {
                Console.WriteLine("num is armstrong:" + num);

            }
            else
            {
                Console.WriteLine("num is not armstrong:" + num);
            }


        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            // prime p = new prime();
            //p.factorial();
            //p.calculate();
            b o = new b();
            o.factorial();
            o.calculate();
            o.armstrong();
            Console.ReadKey();
        }
    }
}
