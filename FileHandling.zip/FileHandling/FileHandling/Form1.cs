﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace FileHandling
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string path = textBox2.Text;
            FileStream fs;
            if (!File.Exists(textBox1.Text))
            {
                fs = new FileStream(textBox1.Text, FileMode.OpenOrCreate, FileAccess.Write);
                MessageBox.Show("file created");
                StreamWriter sw = new StreamWriter(fs);
                sw.Write(textBox2.Text);
                MessageBox.Show("wite complete");
                sw.Flush();
                sw.Close();
                fs.Close();
            }
            else
            {
                MessageBox.Show("exists");
            }
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string path = textBox1.Text;

            FileStream fs = new FileStream(textBox1.Text, FileMode.OpenOrCreate, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string s = sr.ReadToEnd();
            textBox3.Text = s;
            
            sr.Close();
            fs.Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string path = textBox2.Text;
            FileStream fs = new FileStream(textBox1.Text, FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(textBox4.Text);
            sw.Flush();
            sw.Close();
            fs.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string path = textBox1.Text;
            FileStream fs = new FileStream(textBox1.Text, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(fs);
            string s = sr.ReadToEnd();
            //MessageBox.Show("s=" + s);
            string s1 = textBox2.Text;
           // int cnt = 0;
            if (s.Contains(s1))
            {
             
                MessageBox.Show("present");
            }
            else
            {
                MessageBox.Show("notpresent");
            }
            
            sr.Close();
            fs.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FileStream fs;
            if (File.Exists(textBox1.Text))
            {
                File.Delete(textBox1.Text);
               //fs = new FileStream(textBox1.Text, FileMode.OpenOrCreate, FileAccess.Write);
                MessageBox.Show("file deleted");
            }
            else
            {
                MessageBox.Show("not deleted");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string s = textBox2.Text;
            char[] separator = {' '};
            int wordcnt = s.Split(separator,StringSplitOptions.RemoveEmptyEntries).Length;
            MessageBox.Show(wordcnt.ToString());



            string p = textBox1.Text;
            FileStream fs = new FileStream(p, FileMode.Open, FileAccess.Read);
            StreamReader sr = new StreamReader(p);

            string data = sr.ReadToEnd();
            data = data.Replace("\r\n", "\r");

            int charcnt = data.Length;
            int linecnt = data.Split('\r').Length;
            int wordcnt1 = data.Split('\r',' ').Length;

            MessageBox.Show("w:"+wordcnt1.ToString());
            MessageBox.Show("c:"+charcnt.ToString());
            MessageBox.Show("l:"+linecnt.ToString());

            sr.Close();
            fs.Close();
        }
    }
}
