﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Basic_window
{
    public partial class Form1 : Form
    {
        int s;
        DataGridView dataGridView = new DataGridView();
        DataTable dt,dt1;
        List<employee> l = new List<employee>();
        int time = 100;
        int time2 = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Location = new Point(0, 0);
            timer1.Enabled = true;
            //timer3.Enabled = true;
            timer4.Enabled = true;

            dt1 = new DataTable();
            dt1.Columns.Add("usr", typeof(string));
            dt1.Columns.Add("pass", typeof(string));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Location = new Point(label1.Location.X + 5, label1.Location.Y);
            if (label1.Location.X > this.Width)
            {
                label1.Location = new Point(0, 0);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dt1.Rows.Add(textBox1.Text,textBox2.Text);
            dt1.Rows.Add(textBox1.Text,textBox2.Text);
            dataGridView1.DataSource = dt1;
            textBox1.Text = "";
            textBox2.Text = "";
            int i = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows.RemoveAt(i);

            string s = textBox1.Text;
            string s2 = textBox1.Text;
            if (s == s2)
            {
                timer2.Enabled = true;
               
            }
            else
            {
                MessageBox.Show("Invalid user");
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value == 100)
            {
                timer2.Enabled = false;
                Form2 f = new Form2();
                f.Show();
                MessageBox.Show("Login successful");
            }
            else
            {
                progressBar1.Value = progressBar1.Value + 5;
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
          //  time--;
          //  label4.Text = time.ToString();
          //  if (time == 0)
            {
              //  timer3.Enabled = false;
             //   MessageBox.Show("Time up");
             //  this.Close();
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                //comboBox2.Items.Clear();
                comboBox2.Items.Add("Palus");
                comboBox2.Items.Add("Tasgoan");
            }
            if (comboBox1.SelectedIndex == 1)
            {
               // comboBox2.Items.Clear();

                comboBox2.Items.Add("Sangola");
                comboBox2.Items.Add("Mangalveda");
            }
        }

        private void timer4_Tick(object sender, EventArgs e)
        {
            time2++;
            if(time2 > 5){
                timer4.Enabled = false;
               // this.Hide();
                Form2  f2= new Form2();
              //  f2.Show();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                s = 2000000;
                textBox5.Text = Convert.ToString(s);
            }
          
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                s = 3000000;
                textBox5.Text = Convert.ToString(s);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            int i = Convert.ToInt32(textBox3.Text);
            string str1 = textBox4.Text;
            l.Add(new employee() { id=i,str=str1});
            MessageBox.Show(i + "" + str1 + "" + s);

            dt = new DataTable();
            dt.Columns.Add("id", typeof(int));
            dt.Columns.Add("str", typeof(string));
           // dataGridView1.DataSource = "";
            //dataGridView1.DataSource = l;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = "";
            dataGridView1.DataSource = l;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            l.Sort();
            dataGridView1.DataSource = "";
            dataGridView1.DataSource = l;
        }

        private void textBox6_Enter(object sender, EventArgs e)
        {
            textBox6.Text = "";
        }

        private void textBox6_Leave(object sender, EventArgs e)
        {
            textBox6.Text = "Enter name";
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            foreach(Object o in listBox1.SelectedItems)
            {
                MessageBox.Show(o.ToString());
            }
        }
    }
    public class employee : IComparable<employee>
    {
        public int id {set;get;}
        public string str { set; get; }
        public int CompareTo(employee other)
        {
            if (this.id > other.id)
            {
                return 1;
            }
            else
            {
                return 0;
            }
            throw new NotImplementedException();
        }
    }
}
