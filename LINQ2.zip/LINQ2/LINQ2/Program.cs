﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace LINQ2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] age = { 23, 44, 54, 34, 65 };
            //int temp;
            var result = from temp in age where temp > 40 orderby temp descending select temp;
            foreach(var i in result)
            {
                Console.WriteLine(i);
            }
            var result2 = age.Where(i => i < 40).OrderByDescending(i => i).Select(i => i);
            foreach (var i in result2)
            {
                Console.WriteLine(i);
            }
            Console.ReadKey();
        }
    }
}
