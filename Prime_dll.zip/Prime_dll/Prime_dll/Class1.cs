﻿using System;

namespace Prime_dll
{
    public class Class1
    {
        int num,flag=0;
        public void Prime()
        {
            Console.WriteLine("Enter number:");
            num = Convert.ToInt32(Console.ReadLine());
            for(int i = 2; i <= num / 2; i++)
            {
                if (num % i == 0)
                {
                    flag = 1;
                }
            }
            if (flag == 0)
            {
                Console.WriteLine("Prime");
            }
            else
            {
                Console.WriteLine("Not Prime");
            }
                
        }

    }
}
