﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            int num, rem, original, s = 0; ;
            Console.WriteLine("Enter num to check palindrome:");
            num = Convert.ToInt32(Console.ReadLine());
            original = num;
            while (num > 0)
            {
                rem = num % 10;
                s = s*10+rem;
                num = num / 10;
            }
            if (original == s)
            {
                Console.WriteLine("Palindrome\n");
            }
            else
            {
                Console.WriteLine("Not Palindrome\n");
            }
            Console.WriteLine("...............................................................\n");
            Console.WriteLine("Enter string:");
            string s1 = Console.ReadLine();
            int n = s1.Length;
            string re="";
            for (int i = n-1; i>=0; i--)
            {
                re = re+s1[i].ToString();
                
            }
            if (re == s1)
            {
                Console.WriteLine("Palindrome\n");
            }
            else
            {
                Console.WriteLine("Not Palindrome\n");
            }

            Console.ReadKey();
        }
    }
}
