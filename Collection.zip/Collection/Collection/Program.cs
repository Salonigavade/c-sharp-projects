﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using collDemoDll;

namespace Collection
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList al = new ArrayList();
            al.Add(10);
            al.Add("saloni");
            al.Add(20.29);
            foreach(Object o in al)
            {
                Console.WriteLine(o);
            }
            al.Remove(20.29);
            al.Insert(2,"riyansh");
            Console.WriteLine();
            foreach (Object o in al)
            {
                Console.WriteLine(o);
            }
            ArrayList al1 = new ArrayList(2);
            Console.WriteLine("capacity"+al1.Capacity);
            al1.Add(90);
            Console.WriteLine("Capacity"+al1.Capacity);
            Console.WriteLine("\n...........................\n");

            Hashtable ht = new Hashtable();
            ht.Add("1","saloni");
            ht.Add("2","shubham");
            if (ht.ContainsValue("Riyansh"))
            {
                Console.WriteLine("Value already present");
            }
            else
            {
                ht.Add("3", "Riyansh");
            }
            ICollection key = ht.Keys;
            foreach(string k in key)
            {
                Console.WriteLine(k + ":" + ht[k]);
            }

            Console.WriteLine("\n...........................\n");
            Program p = new Program();
            p.Compare(10, 20);
            p.Compare(10.2f, 10.30f);

            Console.WriteLine("\n...........................\n");


            student s = new student() { id = 1, age = "20" };
            student s1 = new student() { id = 2, age = "19" };
            List<student> li = new List<student>();
            Console.ReadKey();
        }
        void Compare(Object a,Object b)
        {
            if (a == b)
            {
                Console.WriteLine("Equal");
            }
            else
            {
                Console.WriteLine("not equal");
            }
        }
    }

   
}
