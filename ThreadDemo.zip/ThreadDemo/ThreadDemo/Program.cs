﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace ThreadDemo
{
    class Program
    {
        public static void task1()
        {
            for(int i=0;i<=10;i++)
            {
                Console.WriteLine("Task1:" + i);
            }
        }
        public static void task2()
        {
            for(int i = 0; i <= 10; i++)
            {
                Console.WriteLine("Task2:" + i);
            }
        }
        static void Main(string[] args)
        {
             Thread t1 = new Thread(task1);
                Thread t2 = new Thread(task2);
             t1.Start();
             t2.Start();
            t1.Join(300);
            t2.Join();
            //task1();
            //task2();

            //ThreadStart ts = new ThreadStart(task1);
            //Thread t = new Thread(ts);
            //t.Start();

           /** ParameterizedThreadStart pts = new ParameterizedThreadStart(task3);
            Thread t = new Thread(pts);
            t.Start(20);*/
            Console.ReadKey();
        }
        /*public static void task3(Object o)
        {
            int r = Convert.ToInt32(o);
            for(int i = 0; i <= r; i++)
            {
                Console.WriteLine("task3::" + i);
            }
        }*/
    }
}
