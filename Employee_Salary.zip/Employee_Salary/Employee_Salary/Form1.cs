﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Employee_Salary
{
    public partial class Form1 : Form
    {
        public int sal;
        public int a1,b;
        public Form1()
        {

            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        /**  private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
          {
              int a1 = comboBox2.SelectedIndex;
              if (a1 == 0)
                  sal = 30000;
              else if (a1 == 1)
                  sal = 40000;
              else if (a1 == 2)
                  sal = 50000;
              else if (a1 == 3)
                  sal = 100000;

              string s = Convert.ToString(a1);
              textBox2.Text = s;
          }*/

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int a = comboBox1.SelectedIndex;
            if (a == 0)
            {
                a1 = 20000;
                b = 5000;
                sal = a1 + 20000;
                checkBox1.Checked = true;
                checkBox3.Checked = true;
                checkBox5.Checked = true;
            }
            else if (a == 1)
            {
                a1 = 30000;
                b = 6000;
                sal = a1 + 30000;
                checkBox2.Checked = true;
                checkBox4.Checked = true;
                checkBox6.Checked = true;
            }
            else if (a == 2) { 
                a1 = 40000;
                b = 7000;
                  sal = a1 + 25000;
                checkBox1.Checked = true;
                checkBox4.Checked = true;
                checkBox5.Checked = true;
            }
            else if (a == 3)
            {
                 a1=50000;
                b = 8000;
                sal = a1 + 15000;
                checkBox2.Checked = true;
                checkBox3.Checked = true;
                checkBox6.Checked = true;
            }
            string s = Convert.ToString(a1);
            textBox3.Text = s;
            string s1 = Convert.ToString(a);
           // textBox2.Text = s1;

         /*   int a1 = comboBox1.SelectedIndex;
            if (a1 == 0)
                sal = 30000;
            else if (a1 == 1)
                sal = 40000;
            else if (a1 == 2)
                sal = 50000;
            else if (a1 == 3)
                sal = 100000;

            string s1 = Convert.ToString(a1);
            textBox3.Text = s1;*/
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            sal = sal + 10000;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            sal = sal + 15000;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            sal = sal + 20000;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            sal = sal + 25000;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            sal = sal - 10000;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            sal = sal - 15000;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string a = Convert.ToString(sal);
            textBox2.Text = a;

            checkBox1.Checked = false;
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            checkBox4.Checked = false;
            checkBox5.Checked = false;
            checkBox6.Checked = false;
        }
    }
}
