﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Notepad1
{
    public partial class Form1 : Form
    {
        public static string ReplaceText;
        public static string FindText;
       
        public static Boolean matchcase;
        int d;
        int x;                                              
        public Form1()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "")
            {

            }
            else
            {
                DialogResult dr = MessageBox.Show("Do u want to save", "Untitked-Notepad", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                {
                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        string path = saveFileDialog1.FileName;
                        StreamWriter sw = new StreamWriter(path);
                        sw.Write(richTextBox1.Text);
                        sw.Flush();
                        sw.Close();
                    }
                }
                if (dr == DialogResult.No)
                {
                    richTextBox1.Clear();
                }
                if (dr == DialogResult.Cancel)
                {

                }
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text == "")
            {
                if (openFileDialog1.ShowDialog()== DialogResult.OK)
                {
                    string path = openFileDialog1.FileName;
                    StreamReader sr = new StreamReader(path);
                    richTextBox1.Text = sr.ReadToEnd();
                    this.Text = openFileDialog1.FileName;
                    sr.Close();

                }
            }
            else
            {
                DialogResult dr = MessageBox.Show("Do u want to save:", "Untitled-Notepad", MessageBoxButtons.YesNoCancel);
                if (dr == DialogResult.Yes)
                {
                    if (openFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        string path = openFileDialog1.FileName;
                        StreamReader sr = new StreamReader(path);
                        richTextBox1.Text = sr.ReadToEnd();
                        this.Text = openFileDialog1.FileName;
                        sr.Close();
                    }
                }
                if (dr ==DialogResult.No)
                {
                    richTextBox1.Clear();
                }
                if (dr == DialogResult.Cancel)
                {

                }
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string path = saveFileDialog1.FileName;
                StreamWriter sw = new StreamWriter(path);
                sw.Write(richTextBox1.Text);
                sw.Flush();
                sw.Close();
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Text Document(*.txt)|*.txt|All Files(*.*)|*.*";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string path = saveFileDialog1.FileName;
                if (!File.Exists(path))
                {
                    StreamWriter sw = new StreamWriter(path);
                    sw.Write(richTextBox1.Text);
                    sw.Flush();
                    sw.Close();
                }

                else
                {
                    if (File.Exists(path))
                    {
                        StreamWriter sw = new StreamWriter(path);
                        sw.Write(richTextBox1.Text);
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Undo();
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Copy();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Cut();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Paste();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (richTextBox1.Text != "")
            {
                richTextBox1.Cut();
                pasteToolStripMenuItem.Enabled = false;
            }
        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 f1 = new Form2();
            f1.ShowDialog();
           if(FindText!="")
            {
                d=richTextBox1.Find(FindText);
            }
           // MessageBox.Show(FindText);
        }
      
        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fontDialog1.Font = richTextBox1.SelectionFont;
            fontDialog1.Color = richTextBox1.SelectionColor;
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                richTextBox1.SelectionFont=fontDialog1.Font;
                richTextBox1.SelectionColor = fontDialog1.Color;

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult dr = MessageBox.Show("Do u want to close?", "Untitled-Notepad", MessageBoxButtons.YesNoCancel);
            if (dr == DialogResult.Yes)
            {
                Application.Exit();
            }
            if (dr == DialogResult.No)
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    string path = saveFileDialog1.FileName;
                    StreamWriter sw = new StreamWriter(path);
                    sw.Write(richTextBox1.Text);
                    sw.Flush();
                    sw.Close();
                }
            }
            if (dr == DialogResult.Cancel)
            {

            }
        }

        private void dateTimeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = richTextBox1.Text + DateTime.Now.ToString();
        }

        private void findNextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FindText != "")
            {
                if (matchcase == true)
                {
                    d = richTextBox1.Find(FindText, (d + 1), richTextBox1.Text.Length, RichTextBoxFinds.MatchCase);
                }
                else
                {
                    d = richTextBox1.Find(FindText, (d + 1), richTextBox1.Text.Length, RichTextBoxFinds.None);
                }

            }
        }

        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.ShowDialog();
            richTextBox1.Find(FindText);
            richTextBox1.SelectedText=ReplaceText;
        }
    }
}
