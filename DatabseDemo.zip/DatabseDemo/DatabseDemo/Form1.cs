﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.IO;
using Microsoft.Office.Interop.Excel;

namespace DatabseDemo
{
    public partial class Form1 : Form
    {
        System.Data.DataTable dt;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nm = textBox1.Text;
            int id = Convert.ToInt32(textBox2.Text);
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            
            dt = new System.Data.DataTable();
            try
            {
             
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into studentdemo(Name,RollNo) values('"+nm+"','"+id+"')";
                int result = cmd.ExecuteNonQuery();
                if (result>0)
                {
                    MessageBox.Show("inserted");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("not inserted");
                }

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from studentdemo";
                MySqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                dataGridView1.DataSource = dt;
            
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "delete from studentdemo where Name='" + textBox1.Text + "'";
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("Not Deleted");
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            
            }
            finally
            {
                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "update studentdemo set Name='"+textBox1.Text+"' where RollNo='"+textBox2.Text+"'";
                int result = cmd.ExecuteNonQuery();
                
                if (result > 0)
                {
                    MessageBox.Show("Updated");
                }
                else
                {
                    MessageBox.Show("Not updated");
                }
            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());

            }
            finally
            {
                con.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from studentdemo where Name='"+textBox1.Text+"'";
                MySqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt.Load(dr);
                    dataGridView1.DataSource = dt;
                    MessageBox.Show("present"); 

                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("not  present");
                }

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
                
            }
            finally
            {
                con.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }
    }
}
