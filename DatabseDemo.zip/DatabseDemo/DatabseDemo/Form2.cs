﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;
using MySql.Data;
using Microsoft.Office.Interop.Excel;

namespace DatabseDemo
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            MySqlDataAdapter mySqlAdapter = new MySqlDataAdapter();
            DataSet ds = new DataSet();
            System.Data.DataTable dt = new System.Data.DataTable();
            System.Data.DataTable dt1 = new System.Data.DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from studentdemo";
                MySqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);

                mySqlAdapter.SelectCommand = cmd;
                mySqlAdapter.Fill(ds, "satudentdemo");
                //dataGridView1.DataSource = dt;
                cmd.CommandText = "select * from register";
                MySqlDataReader dr1 = cmd.ExecuteReader();
                dt1.Load(dr1);
                mySqlAdapter.SelectCommand = cmd;
                mySqlAdapter.Fill(ds, "register");
                // dataGridView2.DataSource = dt1;


                dataGridView1.DataSource = ds.Tables[0];
                dataGridView2.DataSource = ds.Tables[1];


            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application xlapplication;
            Microsoft.Office.Interop.Excel.Workbook xlworkbook;
            Microsoft.Office.Interop.Excel.Worksheet xlworksheet;
            Object misvalue = System.Reflection.Missing.Value;
            xlapplication = new Microsoft.Office.Interop.Excel.Application();
            xlworkbook = xlapplication.Workbooks.Add();
            xlworksheet = (Microsoft.Office.Interop.Excel.Worksheet)xlworkbook.Worksheets.get_Item(1);
            int i = 0;
            int j = 0;
            for (i = 0; i <= dataGridView1.RowCount - 1; i++)
            {
                for (j = 0; i <= dataGridView1.ColumnCount - 1; j++)
                {
                    DataGridViewCell cell =dataGridView1[j, i];
                    xlworksheet.Cells[i+1,j+1] = cell.Value;
                }
            }
            MessageBox.Show("Done");
            xlworkbook.SaveAs("databaseDemo2");
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into register (Name,Password) values('"+textBox1.Text+"','"+textBox2.Text+"')";
                int res = cmd.ExecuteNonQuery();
                if (res > 0)
                {
                    MessageBox.Show("inserted");
                    textBox1.Text = "";
                    textBox2.Text = "";
                }
                else
                {
                    MessageBox.Show("not inserted");
                }
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;
            string str1 = textBox2.Text;
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from register where Name='" + str + "'and Password='" + str1 + "'";
                MySqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    string ss = Convert.ToString(dr["Name"]);
                    string ss1= Convert.ToString(dr["Password"]);
                    if(ss==str && ss1 == str1)
                    {
                        MessageBox.Show("successful");
                        Form3 f3 = new Form3();
                        f3.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("invalid user");
                    }
                }
            }
            catch(Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}

