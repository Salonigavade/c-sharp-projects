﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameter_Passing
{
    class Ref
    {
        public void add(ref int a)
        {
            a++;
            Console.WriteLine("a_ref=" + a);
        }
        public void add2(out int l)
        {
            l = 9;
            l++;
            Console.WriteLine("l_out=" + l);
        }
        public void arrayPass(int [] a)
        {
            Console.WriteLine("After passing:");
            for(int i=0;i<a.Length; i++)
            {
                a[i] = a[i] + 1;
                Console.WriteLine(a[i]);
               
            }
        }
        public void array2D(int [,] a1,int row,int col)
        {
            Console.WriteLine("2D array elements are:");
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.WriteLine(a1[i, j]);

                }
            }

        }
    }
}
