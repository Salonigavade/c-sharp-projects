﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameter_Passing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            a = 10;
            Ref r = new Ref();
            r.add(ref a);
            Console.WriteLine("a=" + a);
            int l;
            r.add2(out l);
            Console.WriteLine("l=" + l);
            Console.WriteLine("\n...............................................\n");

            int n,s=0;
            Console.WriteLine("Enter array size:");
            n = Convert.ToInt32(Console.ReadLine());
            int[] arr = new int[n];
            Console.WriteLine("Enter array elements:");
            for(int i = 0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.WriteLine("array elements:");
            for (int i = 0; i < arr.Length; i++)
            {
                s = s + arr[i];
                Console.WriteLine(arr[i]);
            }
            Console.WriteLine("sum is: " + s);
            Ref ar = new Ref(); 
            ar.arrayPass(arr);

            Console.WriteLine("\n...............................................\n");

            Console.WriteLine("Enter row and col");
            int row = Convert.ToInt32(Console.ReadLine());
            int col = Convert.ToInt32(Convert.ToInt32(Console.ReadLine()));
            int[,] a1 = new int[row, col];
            Console.WriteLine("Enter 2D array elements:");
            for(int i = 0; i < row; i++)
            {
                for(int j = 0; j < col; j++)
                {
                    a1[i, j] = Convert.ToInt32(Console.ReadLine());

                }
            }
            ar.array2D(a1,row,col);

            Console.WriteLine("\n...............................................\n");

            int[][] q = new int[3][];
            q[0] = new int[2] { 1, 2};
            q[1] = new int[3] { 11, 22, 33 };
            q[2]= new int[4] { 22, 55, 77, 99 };
            for(int i = 0; i <3; i++)
            {
                for(int j = 0; j <q[i].Length; j++)
                {
                    Console.WriteLine(q[i][j]);
                }
            }
           /* for (int i = 0; i <3; i++)
            {
                for (int j = 0; j < i; j++)
                {
                   q[i][j]=Convert.ToInt32(Console.ReadLine());
                }
            }*/
            Console.ReadKey();
        }
    }
}
