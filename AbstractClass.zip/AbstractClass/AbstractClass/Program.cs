﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClass
{
    abstract class A
    {
        public abstract void armstrong();
        public void fibonicci()
        {
            int num,f = 0, s = 1, next=0;
            Console.WriteLine("Enter num u want to find fibonicci:");
            num = Convert.ToInt32(Console.ReadLine());
            if (num == 0)
            {
                Console.WriteLine(f);
            }
            else if (num == 1)
            {
                Console.WriteLine(s);
            }
            else if (num > 0)
            {
                Console.WriteLine(f);
                Console.WriteLine(s);
                for (int i = 2; i < num; i++)

                {
                    next = f + s;
                    Console.WriteLine(next);
                    f = s;
                    s = next;
                }
            }
        }
    }
    class B:A
    {
        public override void armstrong()
        {
            int rem, s=0, num,original;
            Console.WriteLine("Enter num u want to find armstrong :");
            num = Convert.ToInt32(Console.ReadLine());
            original = num;
            while (num > 0)
            {
                rem = num % 10;
                s = s + (rem * rem * rem);
                num = num / 10;
            }
            if (original == s)
            {
                Console.WriteLine("Armstrong number:" + original);
            }
            else
            {
                Console.WriteLine(" Not Armstrong number:" + original);
            }

            //throw new NotImplementedException();
        }

       
    }
    class Program
    {
        static void Main(string[] args)
        {
            B obj = new B();
            obj.armstrong();
            //A a = new A();
            obj.fibonicci();
            Console.ReadKey();
                
        }
    }
}
