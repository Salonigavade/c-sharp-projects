﻿using Interface_1;
using System;

namespace Interface_1
{
    public interface emp
    {
        void employee();
        void customer();
    }

    public class detail : emp
    {
        public void employee()
        {
            Console.WriteLine("Enter employee name and age:");
            string nm1 = Console.ReadLine();
            int age1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Displaying customer details: " + nm1 + "\t" + age1);
        }
        public void customer()
        {
            Console.WriteLine("Enter customer name and age:");
            string nm = Console.ReadLine();
            int age = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Displaying customer details: " + nm + "\t" + age);

        }

        
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        detail d = new detail();
        d.customer();
        d.employee();
        Console.ReadKey();
        }
    }
}
