﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;

namespace MultiThread
{
    class Program
    {
        public static void task1()
        {
            int cnt = 0;
            for(int i = 0; i <= 10000000; i++)
            {
                cnt++;
            }
            Console.WriteLine("Task1:" + cnt);
        }
        public static void task2()
        {
            int cnt2 = 0;
            for(int i = 0; i <= 10000000; i++)
            {
                cnt2++;
            }
            Console.WriteLine("Task2::" + cnt2);
        }
        static void Main(string[] args)
        {
            /* Stopwatch se = new Stopwatch();
             se.Start();
             task1();
             task2();
             se.Stop();
             Console.WriteLine(se.ElapsedMilliseconds);*/

            Thread t1 = new Thread(task1);
            Thread t2 = new Thread(task2);
            Stopwatch sw = new Stopwatch();
            sw.Start();
            t1.Start();
            t2.Start();
            sw.Stop();
            t1.Join();
            t2.Join(300);
            Console.WriteLine(sw.ElapsedMilliseconds);
            Console.ReadKey();
        }
    }
}
