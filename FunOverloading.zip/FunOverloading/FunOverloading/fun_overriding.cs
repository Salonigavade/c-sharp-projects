﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FunOverloading
{
    class fun_overriding
    {
        public static void prime()
        {
            int flag;
            for(int i=2;i<=100;i++)
            {
               flag = 0;
                for(int j=2;j<=i/2;j++)
                {
                    if(i%j==0)
                    {
                        flag = 1;
                        break;
                    }
                }
                if (flag == 0)
                {
                    Console.WriteLine("prime: " + i);
                }
               
            }
          
        }
        public static void show()
        {
            Console.WriteLine("Hello...................");
        }
        
    }
    class overide:fun_overriding
    {
        public static void prime()
        {
            int n = 10, n2 = 80;
            int result = n + n2;
            Console.WriteLine("Overidding method\n" + result);
        }
    }
}
