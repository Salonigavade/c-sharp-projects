﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;
namespace FunOverloading
{
    class interfaceDemo
    {
    }
        interface A
        {
            void stack();
        }
        interface B
        {
            void showB();
        }
        interface c: A, B
         {
            void showC();
        }
        public class D : c
        {
            public void showB()
            {
                Console.WriteLine("Inside B........\n");
            }

            public void showC()
            {
                Console.WriteLine("Inside C..........\n");
            }

            public void stack()
            {
                Stack s = new Stack();
                s.Push(10);
                s.Push(20);
                s.Push(30);
                Console.WriteLine("Count :"+s.Count);
                foreach (Object obj in s)
                {
                    Console.WriteLine("{0}", obj);
                }
                s.Pop();
                Console.WriteLine("count :"+s.Count);
                //PrintValues(s);
            }       
        }
    }

