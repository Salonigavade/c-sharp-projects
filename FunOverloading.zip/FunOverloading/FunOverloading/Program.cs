﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//using static FunOverloading.interfaceDemo;

namespace FunOverloading
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Sum=" + fun_overloading.sum(2, 3)) ;
            Console.WriteLine("Sum=" + fun_overloading.sum(2, 3,4));
            Console.WriteLine("Sum=" + fun_overloading.sum(2.4,8.2));
            Console.WriteLine("\n.......................................\n");

           // fun_overriding.prime();while overriding call only overriding class method using that class name itself not the parent class
            overide.prime();
            overide.show();

            Console.WriteLine("\n.......................................\n");

            D obj = new D();
            obj.showB();
            obj.showC();
            obj.stack();
            Console.ReadKey();
        }
    }
    class fun_overloading
    {
        public static int sum(int n,int n1)
        {
            return (n + n1);
        }
        public static int sum(int n,int n1,int n2)
        {
            return (n + n1 + n2);
        }
        public static double sum(double n3,double n4)
        {
            return (n3 + n4);
        }
    }
}
