﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace Database
{
    public partial class Report : Form
    {
        public static string entry_date, exit_date;
        public static int id;
        public Report()
        {
            InitializeComponent();
        }

        private void Report_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from report";
                MySqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                dataGridView1.DataSource = dt;

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f4 = new Form2();
            f4.ShowDialog();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            int a =Convert.ToInt32( textBox1.Text);
            //MessageBox.Show(a + " ");
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from login";
                MySqlDataReader dr = cmd.ExecuteReader();
                while(dr.Read())
                {
                    //int d=Convert.ToInt32( dr.GetInt32(2));
                    int g = Convert.ToInt32(dr["p_id"]);
                    //MessageBox.Show( " in while");
                    if(a == g)
                    {
                     //   MessageBox.Show(" in if");
                        string ss =Convert.ToString( dr["entry_date"]);
                        textBox2.Text = ss;
                        break;
                    }
                }
               // dt.Load(dr);
                //dataGridView1.DataSource = dt;

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            id = Convert.ToInt32(textBox1.Text);
            entry_date = textBox2.Text;
            exit_date = textBox3.Text;

            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into report(id,entry_date,exit_date)values('" + id + "','" + entry_date + "','" + exit_date + "')";
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("report details are inserted..");

                }
                else
                {
                    MessageBox.Show("error..");
                }


            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }

    internal class Date
    {
    }
}
