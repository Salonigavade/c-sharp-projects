﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace Database
{
    public partial class Form1 : Form
    {
        public static string name, entry_date;
        public static int p_id;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //String nm=textBox1.Text;
            //int id =Convert.ToInt32(textBox2.Text);
            //int date= Convert.ToInt32(textBox3.Text);
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        public void button2_Click(object sender, EventArgs e)
        {
            name = textBox1.Text;
            p_id = Convert.ToInt32(textBox2.Text);
            entry_date = textBox3.Text;
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into login(name,p_id,entry_date)values('" + name + "','" + p_id+ "','" + entry_date + "')";
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("Login details are inserted..");

                }
                else
                {
                    MessageBox.Show("error..");
                }


            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }
    }
}
