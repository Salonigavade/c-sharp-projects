﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using MySql.Data.MySqlClient;

namespace Database
{
    public partial class Patient : Form
    {

        String name, disease;
        int age, id, roomno;
        public Patient()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            /*name = textBox1.Text;
            id = Convert.ToInt32(textBox2.Text);
            age = Convert.ToInt32(textBox3.Text);
            roomno = Convert.ToInt32(textBox4.Text);
            disease = textBox5.Text;
            */
            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select * from patient";
                MySqlDataReader dr = cmd.ExecuteReader();
                dt.Load(dr);
                dataGridView1.DataSource = dt;

            }
            catch (Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            name = textBox1.Text;
            id = Convert.ToInt32(textBox2.Text);
            age = Convert.ToInt32(textBox3.Text);
            roomno = Convert.ToInt32(textBox4.Text);
            disease = textBox5.Text;

            string s = ConfigurationManager.ConnectionStrings["mycon"].ToString();
            MySqlConnection con = new MySqlConnection(s);
            MySqlCommand cmd = new MySqlCommand();
            DataTable dt = new DataTable();
            try
            {
                con.Open();
                cmd.Connection = con;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "insert into patient(name,id,age,roomno,disease)values('"+name+ "','" + id + "','" + age + "','" + roomno+ "','" +disease + "')";
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    MessageBox.Show("patient details are inserted..");

                }
                else
                {
                    MessageBox.Show("error..");
                }
                

            }
                catch(Exception e1)
            {
                MessageBox.Show(e1.ToString());
            }
            finally{
                con.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f4 = new Form2();
            f4.ShowDialog();
        }

        private void Patient_Load(object sender, EventArgs e)
        {

        }
    }
}
