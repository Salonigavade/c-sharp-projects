﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assembly
{
    class Assembly1
    {
        protected internal void show()
        {
            Console.WriteLine("i am executing protected internal access modifier...\n");
        }
        protected internal void add(int a,int b)
        {
            Console.WriteLine("Add=" + (a + b));
        }
    }
    
}
namespace AccessModifier
{
    class program
    {
        internal void show()
        {
            Console.WriteLine("i am executing internal access modifier...\n");
        }
    }
}
