﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AccessModifier;
using Prime_dll;
//using Assembly;

namespace Assembly
{
    class Program:Assembly1
    {
        int no = 10;
        public void setNumber(int Num)
        {
            no = Num;
        }
        public int getNumber()
        {
            return no;
        }
        static void Main(string[] args)
        {
            Program p = new Program();
            p.setNumber(90);
            Console.WriteLine(p.getNumber());

           // Assembly1 a1 = new Assembly1(); internal and protected internal access modifer
            p.show();
            p.add(5, 90);

            program p1 = new program();
            p1.show();

            //Adding dll
            Class1 c = new Class1();
            c.Prime();
            Console.ReadKey();
        }
    }
}
