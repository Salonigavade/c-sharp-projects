﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQ
{
    class Program
    {
        static void Main(string[] args)
        {
            int cnt = 0,index=0; 
            int[] age = { 45, 32, 34, 84, 55, 23, 21 };
           
            for(int i=0;i<age.Length;i++)
            {
                if (age[i] >40)
                {
                    cnt++;
                }
            }
            Console.WriteLine("Count is:" + cnt);
            int[] fourty = new int[cnt];
            for(int j = 0; j <age.Length; j++)
            {
                if (age[j] > 40)
                {
                    fourty[j] = age[j];
                    index++;
                }
            }
            Console.WriteLine("greater than foury....");
            foreach(var i in fourty)
            {
                Console.WriteLine(i);
            }
            Array.Sort(fourty);
            foreach (var i in fourty)
            {
                Console.WriteLine("Sorted array"+i);
            }
            Array.Reverse(fourty);
            foreach (var i in fourty)
            {
                Console.WriteLine("Reverse in descending"+i);
            }
            Console.ReadKey();
        }
    }
}
