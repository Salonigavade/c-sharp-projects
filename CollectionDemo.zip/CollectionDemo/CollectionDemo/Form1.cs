﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollectionDemo
{
    public partial class Form1 : Form
    {
        DataTable dt;
        DataGridView dataGridView = new DataGridView();
        List<student> l=new List<student>();
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            string str = textBox1.Text;
            int id = Convert.ToInt32(textBox2.Text);
            l.Add(new student() { s = str,roll=id });
            dt = new DataTable();
            dt.Columns.Add("name", typeof(string));
            dt.Columns.Add("roll", typeof(int));
            dataGridView1.DataSource = "";
            dataGridView1.DataSource = l;
            
        }
    }
    public class student : IComparable<student>
    {

        public string s { set; get; }
        public int roll { set; get; }
        public int CompareTo(student other)
        {
            if (this.roll > other.roll)
            {
                return 1;
            }
            else
            {
                return 0;
            }
            throw new NotImplementedException();
        }
    }
}
