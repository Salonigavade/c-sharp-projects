﻿using System;

namespace collDemoDll
{
    public class student
    {
        public int id{set; get;}
        public string age { set; get; }
    }
}
