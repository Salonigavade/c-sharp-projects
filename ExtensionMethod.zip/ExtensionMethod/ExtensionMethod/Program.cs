﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod
{
    class Program
    {
        static void Main(string[] args)
        {
            string s = "saloni";
            Console.WriteLine(s.ToLower());
            Console.WriteLine(s.ToUpper());
            string s1;
            Console.WriteLine("Enter the string:");
            s1 = Console.ReadLine();
            Console.WriteLine("No of vowels are:"+s1.vowelCnt());
            Console.ReadKey();
        }
    }
}
