﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod
{
    public static class vowel
    {
        public static int vowelCnt(this string s1)
        {
            int cnt = 0;
            for(int i = 0; i < s1.Length; i++)
            {
                if (s1[i] == 'a' || s1[i] == 'e' || s1[i] == 'i' || s1[i] == 'o' || s1[i] == 'u')
                {
                    cnt++;
                }
            }
            return cnt;
        }
    }
}
