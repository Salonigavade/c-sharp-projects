﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Synchronization
{
    class printer
    {
        public void printTable()
        {
            lock (this)
            {
                for (int i = 0; i <= 10; i++)
                {
                    Thread.Sleep(100);
                    Console.WriteLine(i);
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            printer p = new printer();
            Thread t = new Thread(p.printTable);
            Thread t2 = new Thread(p.printTable);
            t.Start();
            t2.Start();
            Console.ReadKey();
        }
    }
}
