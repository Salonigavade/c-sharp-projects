﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    public partial class Operation
    {
        public void evenodd()
        {
            int num;
            Console.WriteLine("Enter number:");
            num = Convert.ToInt32(Console.ReadLine());
            if (num % 2 == 0)
            {
                Console.WriteLine("Even number:" + num);
            }
            else
            {
                Console.WriteLine("Not even number:" + num);
            }
        }
    }
}
