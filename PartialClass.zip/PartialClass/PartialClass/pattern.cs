﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    public partial class Operation
    {
        public void Triangle()
        {    
        for(int i=1;i<=5;i++)
            {
                for(int j = 1; j <= i; j++)
                {
                    Console.Write(" *");
                }
                Console.WriteLine();
             }
            for (int i = 1; i <= 5; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(" @");
                }
                Console.WriteLine();
            }
        }
    }
}
