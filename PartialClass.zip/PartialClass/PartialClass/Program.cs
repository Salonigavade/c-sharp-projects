﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PartialClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Operation o = new Operation();
            o.evenodd();
            o.Triangle();
            Console.ReadKey();
        }
    }
}
