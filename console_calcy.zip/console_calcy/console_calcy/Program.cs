﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace console_calcy
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, ch,Result;
            
            Console.WriteLine("Enter two numbers:");
            n1 = Convert.ToInt32(Console.ReadLine());
            n2 = Convert.ToInt32(Console.ReadLine());
            do
            {
                Console.WriteLine("Enter ur choice\n1.add\n2.sub\n3.div\n4.mul\n5.exit\n");
                string s = Console.ReadLine();
                ch = Convert.ToInt32(s);
                switch (ch)
                {
                    case 1:int r = n1 + n2;
                        Console.WriteLine("Addition:\n"+r);
                        break;
                    case 2:
                        int r1 = n1 - n2;
                        Console.WriteLine("Sub:\n"+r1);
                        break;
                    case 3:
                        int r2 = n1 / n2;
                        Console.WriteLine(r2);
                        break;
                    case 4:
                        int r3= n1 * n2;
                        Console.WriteLine(r3);
                        break;
                    case 5:
                        System.Environment.Exit(0);
                        break;
                        
                }
            } while (ch != 5);
        }
    }
}
